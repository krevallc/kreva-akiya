/* KREVA 空き家 検索ページ：地図(Leaflet+地理院タイル+ハザード)＋絞り込み＋カード。
   データは REST /kreva-akiya/v1/search から取得。設定は window.KREVA_AKIYA。 */
(function () {
	'use strict';
	var CFG = window.KREVA_AKIYA || {};
	if (!window.L || !document.getElementById('kakiya-map')) return;

	var PAGE_SIZE = 20; // リスト初期表示件数（「さらに表示」で20件ずつ追加）
	var map, markersLayer, byId = {}, rawItems = [], allItems = [], shownCount = 0;

	// 並び替え・新着絞り込み（クライアント側）
	function applyView() {
		var items = rawItems.slice();
		var newOnly = document.getElementById('f-newonly');
		if (newOnly && newOnly.checked) {
			var limit = Date.now() - 30 * 86400000;
			items = items.filter(function (it) { return it.date && Date.parse(it.date) >= limit; });
		}
		var sortSel = document.getElementById('f-sort');
		var mode = sortSel ? sortSel.value : 'new';
		items.sort(function (a, b) {
			if (mode === 'price_asc' || mode === 'price_desc') {
				var pa = (a.price == null) ? null : a.price, pb = (b.price == null) ? null : b.price;
				if (pa == null && pb == null) return 0;
				if (pa == null) return 1;  // 価格応談は末尾
				if (pb == null) return -1;
				return mode === 'price_asc' ? pa - pb : pb - pa;
			}
			if (mode === 'land_desc') {
				return (b.land_area || 0) - (a.land_area || 0);
			}
			// new: 取り込み日の新しい順（同日はKREVA物件優先）
			var d = String(b.date || '').localeCompare(String(a.date || ''));
			return d !== 0 ? d : (b.is_kreva ? 1 : 0) - (a.is_kreva ? 1 : 0);
		});
		setCount(items.length);
		render(items);
	}

	function baseLayers() {
		var out = {};
		Object.keys(CFG.baseTiles || {}).forEach(function (k) {
			var t = CFG.baseTiles[k];
			out[t.label] = L.tileLayer(t.url, { attribution: t.attr, maxZoom: 18 });
		});
		return out;
	}

	function hazardLayers() {
		var out = {};
		(CFG.hazardTiles || []).forEach(function (h) {
			out[h.label] = L.tileLayer(h.url, { opacity: 0.6, maxNativeZoom: 17, maxZoom: 18 });
		});
		return out;
	}

	function initMap() {
		var bases = baseLayers();
		var first = bases[Object.keys(bases)[0]];
		map = L.map('kakiya-map', {
			center: CFG.defaultCenter || [34.66, 133.75],
			zoom: CFG.defaultZoom || 10,
			layers: [first]
		});
		L.control.layers(bases, hazardLayers(), { collapsed: true }).addTo(map);
		L.control.attribution({ prefix: false }).addAttribution(CFG.attribution || '').addTo(map);
		markersLayer = L.layerGroup().addTo(map);
	}

	function collectFilters() {
		var params = { per_page: 500 }; // 全件表示（既定200では県全域をカバーできない）
		document.querySelectorAll('[data-filter]').forEach(function (el) {
			var key = el.getAttribute('data-filter');
			if (el.type === 'checkbox') {
				if (el.checked) params[key] = el.value;
			} else if (el.value !== '') {
				params[key] = el.value;
			}
		});
		// 万円 → 円
		if (params.price_min_man) { params.price_min = (parseFloat(params.price_min_man) || 0) * 10000; delete params.price_min_man; }
		if (params.price_max_man) { params.price_max = (parseFloat(params.price_max_man) || 0) * 10000; delete params.price_max_man; }
		return params;
	}

	function fetchItems() {
		var params = collectFilters();
		var qs = Object.keys(params).map(function (k) {
			return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
		}).join('&');
		var url = CFG.restSearch + (qs ? '?' + qs : '');
		setStatus('検索中…');
		fetch(url, { headers: { 'Accept': 'application/json' } })
			.then(function (r) { return r.json(); })
			.then(function (data) { rawItems = data.items || []; applyView(); })
			.catch(function () { setStatus('取得に失敗しました'); });
	}

	function render(items) {
		allItems = items;
		shownCount = 0;
		markersLayer.clearLayers();
		byId = {};
		var cards = document.getElementById('kakiya-cards');
		cards.innerHTML = '';
		if (!items.length) { updateMoreBtn(); cards.innerHTML = '<p class="kakiya-empty">条件に合う物件がありません。</p>'; return; }

		var bounds = [];
		items.forEach(function (it) {
			var m = L.marker([it.lat, it.lng], { title: it.title, riseOnHover: !!it.is_kreva });
			m.bindPopup(popupHtml(it), { minWidth: 220 });
			m.on('click', function () { highlightCard(it.id); });
			m.addTo(markersLayer);
			byId[it.id] = m;
			bounds.push([it.lat, it.lng]);
		});
		appendCards();
		if (bounds.length) {
			// 左側の絞り込みオーバーレイに隠れないよう左余白を広めに
			var wideLayout = window.innerWidth > 700;
			map.fitBounds(bounds, {
				paddingTopLeft: [wideLayout ? 310 : 30, 30],
				paddingBottomRight: [30, 30],
				maxZoom: 14
			});
		}
	}

	// リストに次のPAGE_SIZE件を追加表示
	function appendCards() {
		var cards = document.getElementById('kakiya-cards');
		allItems.slice(shownCount, shownCount + PAGE_SIZE).forEach(function (it) {
			cards.appendChild(cardEl(it));
		});
		shownCount = Math.min(shownCount + PAGE_SIZE, allItems.length);
		updateMoreBtn();
	}

	function updateMoreBtn() {
		var old = document.getElementById('kakiya-more');
		if (old) old.remove();
		if (shownCount < allItems.length) {
			var b = document.createElement('button');
			b.type = 'button';
			b.id = 'kakiya-more';
			b.className = 'kakiya-btn kakiya-more';
			b.textContent = 'さらに表示（残り ' + (allItems.length - shownCount) + ' 件）';
			b.addEventListener('click', appendCards);
			var cards = document.getElementById('kakiya-cards');
			cards.parentNode.insertBefore(b, cards.nextSibling);
		}
	}

	// ピンのポップアップ＝カード風。全体クリックで物件詳細へ
	function popupHtml(it) {
		var img = it.thumb
			? '<img class="kakiya-pop-img" referrerpolicy="no-referrer" src="' + esc(it.thumb) + '" alt="" onerror="this.style.display=\'none\'">'
			: '';
		return '<a class="kakiya-pop-card" href="' + esc(it.permalink) + '">' + img +
			(it.is_kreva ? '<span class="kakiya-pin-badge">KREVA</span>' : '') +
			'<span class="kakiya-pop-price">' + esc(it.price_label || '') + '</span>' +
			'<span class="kakiya-pop-title">' + esc(it.title) + '</span>' +
			'<span class="kakiya-pop-meta">' + esc([it.city, it.type].filter(Boolean).join(' / ')) + '</span>' +
			'<span class="kakiya-pop-link">詳細を見る →</span></a>';
	}

	// 写真が無い物件用：物件位置を中心にした地理院タイルの地図サムネを生成
	function mapThumbHtml(lat, lng) {
		var z = 15, n = Math.pow(2, z);
		var px = (lng + 180) / 360 * n * 256;
		var latRad = lat * Math.PI / 180;
		var py = (1 - Math.asinh(Math.tan(latRad)) / Math.PI) / 2 * n * 256;
		var half = 170, halfH = 80; // 想定最大サムネ幅340px・高さ160pxぶんのタイルを敷く
		var tiles = '';
		var x0 = Math.floor((px - half) / 256), x1 = Math.floor((px + half) / 256);
		var y0 = Math.floor((py - halfH) / 256), y1 = Math.floor((py + halfH) / 256);
		for (var tx = x0; tx <= x1; tx++) {
			for (var ty = y0; ty <= y1; ty++) {
				tiles += '<img src="https://cyberjapandata.gsi.go.jp/xyz/pale/' + z + '/' + tx + '/' + ty + '.png" ' +
					'style="position:absolute;left:' + (tx * 256 - px) + 'px;top:' + (ty * 256 - py) + 'px;width:256px;height:256px;max-width:none" alt="" loading="lazy">';
			}
		}
		return '<div class="kakiya-card-thumb kakiya-card-mapthumb">' +
			'<div class="kakiya-mapthumb-inner">' + tiles + '</div>' +
			'<span class="kakiya-mapthumb-pin"></span>' +
			'<span class="kakiya-mapthumb-credit">地図: 地理院タイル</span></div>';
	}

	function cardEl(it) {
		var a = document.createElement('a');
		a.className = 'kakiya-card' + (it.is_kreva ? ' is-kreva' : '');
		a.href = it.permalink;
		a.id = 'card-' + it.id;
		// 状態バッジ（NEW / 価格応談 / 調整区域 / 災害区域）
		var tags = '';
		if (it.is_new) tags += '<span class="kakiya-tag2 t-new">NEW</span>';
		if (it.is_kreva) tags += '<span class="kakiya-tag2 t-kreva">KREVA</span>';
		if (it.price == null) tags += '<span class="kakiya-tag2 t-ask">価格応談</span>';
		if (it.kuiki_kubun && it.kuiki_kubun.indexOf('調整') >= 0) tags += '<span class="kakiya-tag2 t-warn">市街化調整区域</span>';
		if (it.hazard_any) tags += '<span class="kakiya-tag2 t-hz">災害想定区域</span>';
		a.innerHTML =
			(it.thumb ? '<div class="kakiya-card-thumb"><img class="kakiya-thumb-img" loading="lazy" referrerpolicy="no-referrer" alt="" src="' + esc(it.thumb) + '"></div>'
				: mapThumbHtml(it.lat, it.lng)) +
			'<div class="kakiya-card-body">' +
			(tags ? '<div class="kakiya-card-tags">' + tags + '</div>' : '') +
			'<div class="kakiya-card-price">' + esc(it.price_label || '') + '</div>' +
			'<div class="kakiya-card-title">' + esc(it.title) + '</div>' +
			'<div class="kakiya-card-meta">' + esc([it.city, it.type].filter(Boolean).join(' / ')) + '</div>' +
			'</div>';
		a.addEventListener('mouseenter', function () { var mk = byId[it.id]; if (mk) mk.openPopup(); });
		// 外部画像が読めない場合は地図サムネへ自動フォールバック
		var timg = a.querySelector('.kakiya-thumb-img');
		if (timg) {
			timg.addEventListener('error', function () {
				var holder = timg.closest ? timg.closest('.kakiya-card-thumb') : timg.parentNode;
				if (holder) holder.outerHTML = mapThumbHtml(it.lat, it.lng);
			});
		}
		return a;
	}

	function highlightCard(id) {
		var el = document.getElementById('card-' + id);
		if (!el) return;
		document.querySelectorAll('.kakiya-card.active').forEach(function (n) { n.classList.remove('active'); });
		el.classList.add('active');
		el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
	}

	function setCount(n) { var el = document.getElementById('kakiya-count'); if (el) el.textContent = n; }
	function setStatus(s) { var el = document.getElementById('kakiya-count'); if (el) el.textContent = s; }
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
		return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

	document.addEventListener('DOMContentLoaded', function () {
		initMap();
		var btn = document.getElementById('kakiya-apply');
		if (btn) btn.addEventListener('click', fetchItems);
		// 並び替え・新着のみ はクライアント側で即時反映（再取得しない）
		var sortSel = document.getElementById('f-sort');
		if (sortSel) sortSel.addEventListener('change', applyView);
		var newOnly = document.getElementById('f-newonly');
		if (newOnly) newOnly.addEventListener('change', applyView);
		fetchItems();
	});
})();
